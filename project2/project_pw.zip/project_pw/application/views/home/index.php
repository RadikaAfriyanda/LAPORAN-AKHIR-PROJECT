<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- SEO Meta Tags -->
    <meta name="description" content="Create a stylish landing page for your business startup and get leads for the offered services with this HTML landing page template.">
    <meta name="author" content="Inovatik">

    <!-- OG Meta Tags to improve the way the post looks when you share the page on LinkedIn, Facebook, Google+ -->
	<meta property="og:site_name" content="" /> <!-- website name -->
	<meta property="og:site" content="" /> <!-- website link -->
	<meta property="og:title" content=""/> <!-- title shown in the actual shared post -->
	<meta property="og:description" content="" /> <!-- description shown in the actual shared post -->
	<meta property="og:image" content="" /> <!-- image link, make sure it's jpg -->
	<meta property="og:url" content="" /> <!-- where do you want your post to link to -->
	<meta property="og:type" content="article" />

    <!-- Website Title -->
    <title>WISATA DEPOK</title>
    
    <!-- Styles -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,600,700,700i&amp;subset=latin-ext" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.css')?> "/>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/fontawesome-all.css')?>"/>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/swiper.css')?>"/>
	<link rel="stylesheet" href="<?php echo base_url('assets/css/magnific-popup.css')?>"/>
	<link rel="stylesheet" href="<?php echo base_url('assets/css/styles.css')?>"/>
	
	<!-- Favicon  -->
    <link rel="icon" href="images/favicon.png">
</head>
<body data-spy="scroll" data-target=".fixed-top">
    
    <!-- Preloader -->
	<div class="spinner-wrapper">
        <div class="spinner">
            <div class="bounce1"></div>
            <div class="bounce2"></div>
            <div class="bounce3"></div>
        </div>
    </div>
    <!-- end of preloader -->

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
        <!-- Text Logo - Use this if you don't have a graphic logo -->
        <!-- <a class="navbar-brand logo-text page-scroll" href="index.html">Evolo</a> -->
        <!-- Image Logo -->
        <div>

        </div>
        <img width="170px" height="40px" src=""> 
        
        <!-- Mobile Menu Toggle Button -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-awesome fas fa-bars"></span>
            <span class="navbar-toggler-awesome fas fa-times"></span>
        </button>
        <!-- end of mobile menu toggle button -->
        
        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <div class="row">
                <div class="col-lg-11 col-md-11">
                    <div class="">
                        <marquee class="teks-jalan; mt-2">
                            <h6><span>"Melayani Para Wisatawan Dengan Baik"</span></h6>
                        </marquee>
                    </div>
                </div>
            </div>
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link page-scroll" href="#header">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link page-scroll" href="<?php echo base_url('index.php/login1')?>">Login</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link page-scroll" href="<?php echo base_url("index.php/tampil/tempat")?>">Tempat Wisata</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link page-scroll" href="<?php echo base_url("index.php/tampil/refernsi")?>">Referensi Wisata</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link page-scroll" href="<?php echo base_url("index.php/tampil/kecamatan")?>">kecamatan Wisata</a>                
                </li>
                <li class="nav-item">
                    <a class="nav-link page-scroll" href="<?php echo base_url("index.php/tampil/users")?>">User</a>
                </li>
            </ul>
            <span class="nav-item social-icons">
                <span class="fa-stack">
                    <a href="#your-link">
                        <i class="fas fa-circle fa-stack-2x facebook"></i>
                        <i class="fab fa-facebook-f fa-stack-1x"></i>
                    </a>
                </span>
                <span class="fa-stack">
                    <a href="#your-link">
                        <i class="fas fa-circle fa-stack-2x twitter"></i>
                        <i class="fab fa-twitter fa-stack-1x"></i>
                    </a>
                </span>
            </span>
        </div>
    </nav> <!-- end of navbar -->
    <!-- end of navigation -->


    <!-- Header -->
    <header id="header" class="header">
        <div class="header-content" style="padding-top: 120px; padding-bottom: 100px; ">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="text-container">
                            <h3><span class="turquoise">Layanan Untuk Mempermudah </span> Para Wisatawan untuk berlibur</h3>
                            <p class="p-large">Cukup daftar online dari rumah dan periksa hari ini, besok atau lusa.</p>
                            <a class="btn-solid-lg page-scroll" href="<?php echo base_url('index.php/register')?>">Daftar Sekarang</a>
                        </div> <!-- end of text-container -->
                    </div> <!-- end of col -->
                    <div class="col-lg-6">
                        <div class="image-container">
                            <img class="img-fluid" src="<?php echo base_url('assets/images/header-teamwork.svg')?>" alt="alternative" >
                        </div> <!-- end of image-container -->
                    </div> <!-- end of col -->
                </div> <!-- end of row -->
            </div> <!-- end of container -->
        </div> <!-- end of header-content -->
    </header> <!-- end of header -->
    <!-- end of header -->

    <!-- Services -->
    <div id="services" class="cards-1">
        <div class="container">
            <div class="row">
                <div class="col" >

                    <!-- Card -->
                    <div class="card " style="width: 80rem; height: 30rem; margin: 15px;">
                        <img src="<?php echo base_url('assets/images/')?>" style="widht : 160px; height : 150px;" >
                        <div class="card-body">
                            <br>
                            <h4 class="card-title"></h4>                 
                            <br><button type="button" class="btn btn-primary" data-toggle="modal" data-target=".bd-example-modal-lg" style="margin-top : 170px">Detail</button>
                        </div>
                    </div> 
                    <!-- end of card -->

                    <!-- Card -->
                    <div class="card" style="width: 80rem; height: 30rem; margin: 15px;">
                        <img src="<?php echo base_url('assets/images/')?>" style="widht : 160px; height : 150px; margin-bottom : 20px">
                        <div class="card-body" >
                            <h4 class="card-title">/h4>
                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target=".example" style="margin-top : 192px">Detail</button>
                        </div>
                    </div>
                    <!-- end of card  -->

                    <!-- Card -->
                    <div class="card" style="width: 80rem; height: 30rem; margin: 15px;">
                        <img src="<?php echo base_url('assets/images/')?>" style="width : 280px; height : 220px; margin-bottom : 1px">
                        <div class="card-body">
                        <h4 class="card-title" ></h4>
                        <br>
                        <div align = "left">
                            <p ></p> 
                            <p></p>
                            <p></p>
                        </div>
                        <!-- <div class="card-footer"style="margin-top : 160px"> -->
                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target=".bd">Detail</button>
                        <!-- </div>     -->
                        </div>
                    </div> 
                    <!-- end of card -->

                    <!-- Card -->
                    <div class="card" style="width: 80rem; height: 30rem; margin: 15px;">
                        <img src="<?php echo base_url('assets/images/')?>" style="width : 190px; height : 170px; margin-bottom : 20px">
                        <div class="card-body">
                        <h4 class="card-title"></h4>
                            <br><button type="button" class="btn btn-primary" data-toggle="modal" data-target=".lg" style="margin-top : 150px">Detail</button>
                        </div>
                    </div> 
                    <!-- end of card -->

                    <!-- Card -->
                    <div class="card " style="width: 80rem; height: 30rem; margin: 15px; ">
                        <img src="<?php echo base_url('assets/images/')?>" style="widht : 190px; height : 190px;" >
                        <div class="card-body">
                        <br/>
                            <h5 class="card-title"></h5>
                            <div class="btn" style="margin-top : 150px">
                                <button type="button" class="btn btn-primary " data-toggle="modal" data-target=".modul">Detail</button>
                            </div>
                        </div>
                    </div>
                    <!-- end of card -->

                    <div class="modal fade lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                            <div class="container">
                                <div class="row">
                                    <div class="col-4">
                                        
                                        <div style="width: 16rem; height: 22rem; padding-top: 12px;">
                                            <img src="<?php echo base_url('dist/img/alun-alun.jpg')?>" style="widht : 190px; height : 190px;" >
                                            
                                            <p style="margin-top : 15px;"><b>1. Alun - Alun Depok.
                                                <br/> Jl. Boulevard Grand Depok City, Kelurahan Jatimulya, Kecamatan Cilodong, Kota Depok, Jawa Barat.
                                                <br>
                                            </b></p> 
                                        </div>
                                       
                                    </div>
                                    <div class="col-5">
                                        <div class="table-responsive-sm">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th class="table-light">Lokasi :</th>
                                                        <th class="table-light">Melayani :</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td class="table-light">Jl. Boulevard Grand Depok City, Kelurahan Jatimulya, Kecamatan Cilodong, Kota Depok, Jawa Barat.</td>
                                                        <td class="table-light"></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="table-responsive-sm">
                                        <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th class="table-light">Jam Operasional</th>
                                                        <th class="table-light">Harga Tiket</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td class="table-light">07.00 - 15.00</td>
                                                        <td class="table-light">FREE</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="col-3">
                                    <?php echo form_open('komentar/daftar')?>
                                        <div class="form-group ">
                    
                                            <label for="nilai_rating" class="col-form-label">Rating</label> 
                                            <div class="col-12">
                                                <select id="nilai_rating" name="nilai_rating" class="custom-select">
                                                    <option value="1">1. jelek</option>
                                                    <option value="2">2. Kurang Bagus</option>
                                                    <option value="3">3. Biasa Aja</option>
                                                    <option value="4">4. Bagus</option>
                                                    <option value="5">5. Sangat Bagus</option>
                                                </select>
                                            </div>
                                        </div> 
                                         <?php 
                                        //foreach ($komentar as $kmn){
                                        ?> 
                                        <div class="form-group">
                                            <label for="message-text" class="col-form-label">Message:</label>
                                            <textarea class="form-control" id="message-text" name="isi"></textarea>
                                        </div>
                                        <div>
                                            <!-- <input type="hidden" name="users_id" value="<?php// echo $kmn->users_id;?>"> -->
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                            <!-- <a href="<?php //echo base_url(); . 'komentar/daftar' .$kmn->$users_id.?>"></a> -->
                                            <button type="button" class="btn btn-primary" data-dismiss="modal">sig in</button>
                                            <!-- <button type="button" class="btn btn-primary"  onclick=" return hapusMahasiswa('Apakah Anda yakin ingin menghapus mahasiswa yang bernama <?= $kmn->isi ?> ?')" >Send</a>>Send</button> --> -->
                                            <!-- <a class="btn btn-light btn-lg" role="button" style="color : black" href="index.php/home?id=<?php=$kmn->id?>"></a> -->
                                        </div> 
                                        <?php 
                                        //}
                                        ?>
                                    <?php echo form_close()?> 
                                    </div>              
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                       <p><b>Alun-Alun Kota Depok merupakan ruang publik yang dapat dikunjungi oleh seluruh lapisan masyarakat. Baik itu anak-anak, remaja hingga dewasa. Hampir di setiap kota atau kabupaten di Indonesia memiliki Alun-Alun yang biasanya difungsikan sebagai pusat kegiatan, baik yang bersifat formal maupun non formal.
                                             Alun-Alun Kota Depok diresmikan pada tahun 2020, di bulan Januari oleh Walikota Depok Mohammad Idris. Dengan menempati lahan seluas 3,9 hektar.
                                             Berikut gambaran tentang Alun-Alun Depok sebagai referensi tempat wisata keluarga maupun tempat berolahraga di Kota Depok.</b></p>
                                    </div>
                                </div>    
                            </div>        
                            </div>
                            </div>
                        </div>
                    </div>

                    <div class="modal fade modul" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                              <div class="container">
                                <div class="row">
                                    <div class="col-4">
                                        <!-- Card -->
                                        <div style="width: 16rem; height: 22rem; padding-top: 12px;">
                                            <img src="<?php echo base_url('dist/img/Situ Penganinan.jpg')?>" style="widht : 190px; height : 190px;" >
                                            <p style="margin-top : 15px;"><b>2. Situ Pengasinan Depok
                                                <br/> Jl. Setu Pengasinan Indah No.27, Kelurahan Pengasinan, Kecamatan Sawangan, Kota Depok, Jawa Barat.
                                            </b></p> 
                                        </div>
                                        <!-- end of card -->
                                    </div>
                                    <div class="col-5">
                                        <div class="table-responsive-sm">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th class="table-light">Lokasi :</th>
                                                        <th class="table-light"></th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td class="table-light">Jl. Setu Pengasinan Indah No.27, Kelurahan Pengasinan, Kecamatan Sawangan, Kota Depok, Jawa Barat.</td>
                                                        <td class="table-light"></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="table-responsive-sm">
                                        <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th class="table-light">Jam Operasional :</th>
                                                        <th class="table-light">Harga Tiket :</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td class="table-light">Pukul 08.00 - 18.00</td>
                                                        <td class="table-light">FREE, hanya membayar biaya parkir kendaraan.</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="col-3">
                                    <form>
                                        <div class="form-group ">
                                            <label for="nilai_rating" class="col-form-label">Rating</label> 
                                            <div class="col-12">
                                                <select id="nilai_rating" name="nilai_rating" class="custom-select">
                                                    <option value="1">1. jelek</option>
                                                    <option value="2">2. Kurang Bagus</option>
                                                    <option value="3">3. Biasa Aja</option>
                                                    <option value="4">4. Bagus</option>
                                                    <option value="5">5. Sangat Bagus</option>
                                                </select>
                                            </div>
                                        </div> 
                                        <div class="form-group">
                                            <label for="message-text" class="col-form-label">Message:</label>
                                            <textarea class="form-control" id="message-text"></textarea>
                                        </div>
                                        <div>
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                            <button type="button" class="btn btn-primary">Send</button>
                                        </div> 
                                    </form>
                                    </div>                
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                       <p><b>Setu Pengasinan merupakan danau buatan yang kedalamannya antara 1 hingga 4 meter, luasnya kira-kira mencapai 6 hektar dengan fungsi utamanya ialah sebagai lokasi serapan air. Setu Pengasinan berada di Kelurahan Pengasinan yang terkenal sebagai kampung jawara sejak zaman dulu. Sejarah mencatat antara tahun 1960 hingga 1990 banyak sekali warganya yang menjadi guru silat dan mendirikan sebuah perguruan silat.
                                             Salah satu panutannya bernama H. Alih Yakub selain beliau memiliki padepokan silat, beliau juga merupakan kepala desa pertama dari Kelurahan Pengasinan, Sawangan Depok ini.</b></p>
                                    </div>
                                </div>        
                              </div>
                            </div>
                        </div>
                    </div>

                    <div class="modal fade bd" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                            <div class="container">
                                <div class="row">
                                    <div class="col-4">
                                       
                                        <div style="width: 16rem; height: 22rem; padding-top: 12px;">
                                            <img src="<?php echo base_url('dist/img/waterpark.jpg')?>" style="widht : 190px; height : 190px;" >
                                            
                                            <p style="margin-top : 15px;"><b>3. Water Park Ceria
                                                <br/>Jl. K.H.M. Usman No. 110, Raya Kukusan, Kecamatan Beji, Kota Depok, Jawa Barat.
                                            </b></p> 
                                        </div>
                                    
                                    </div>
                                    <div class="col-5">
                                        <div class="table-responsive-sm">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th class="table-light">Lokasi :</th>
                                                        <th class="table-light"></th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td class="table-light">Jl. K.H.M. Usman No. 110, Raya Kukusan, Kecamatan Beji, Kota Depok, Jawa Barat.</td>
                                                        <td class="table-light"></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="table-responsive-sm">
                                        <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th class="table-light">Jam Operasional :</th>
                                                        <th class="table-light">Harga Tiket :</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td class="table-light">Pukul 07.00 - 17.00</td>
                                                        <td class="table-light"><option value="1">1. Senin sampai Jumat sebesar Rp. 35.000,- per orang</option></td>
                                                        <td class="table-light"><option value="2">2. Sabtu, Minggu sebesar Rp. 40.000,- per orang</option></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="col-3">
                                    <form>
                                        <div class="form-group ">
                                            <h5>KOMENTAR</h5>
                                            <label for="nilai_rating" class="col-form-label">Rating</label> 
                                            <div class="col-12">
                                                <select id="nilai_rating" name="nilai_rating" class="custom-select">
                                                    <option value="1">1. jelek</option>
                                                    <option value="2">2. Kurang Bagus</option>
                                                    <option value="3">3. Biasa Aja</option>
                                                    <option value="4">4. Bagus</option>
                                                    <option value="5">5. Sangat Bagus</option>
                                                </select>
                                            </div>
                                        </div> 
                                        <div class="form-group">
                                            <label for="message-text" class="col-form-label">Message:</label>
                                            <textarea class="form-control" id="message-text"></textarea>
                                        </div>
                                        <div>
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                            <button type="button" class="btn btn-primary">Send</button>
                                        </div> 
                                    </form>
                                    </div>                
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                       <p><b>Waterpark Ceria atau Kolam Renang Ceria, salah satu kolam renang yang ada di Depok cocok banget untuk tempat berenang anak-anak. Berenang merupakan kegiatan yang paling diminati oleh anak-anak, nggak perduli panas, hujan ataupun malam hari jika kamu ajak mereka untuk berenang pasti langsung mengiyakannya.
                                             Nah, Waterpark Ceria dapat menjadi pilihan bermain air anak yang aman juga seru. Berikut ulasan lengkapnya, sebagai bahan referensi wisata di weekend ini bersama keluarga tercinta.</b></p>
                                    </div>
                                </div>    
                            </div>        
                            </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="modal fade example" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                            <div class="container">
                                <div class="row">
                                    <div class="col-4">
                                        
                                        <div style="width: 16rem; height: 22rem; padding-top: 12px;">
                                            <img src="<?php echo base_url('dist/img/Taman Wiladatika.jpg')?>" style="widht : 190px; height : 190px;" >
                                            
                                            <p style="margin-top : 15px;"><b>4. Taman Wiladatika
                                                <br/> Jl. Jambore, Harjamukti, Kota Depok, Jawa Barat.
                                            </b></p> 
                                        </div>
                                        
                                    </div>
                                    <div class="col-5">
                                        <div class="table-responsive-sm">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th class="table-light">Lokasi :</th>
                                                        <th class="table-light"></th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td class="table-light">Jl. Jambore, Harjamukti, Kota Depok, Jawa Barat.</td>
                                                        <td class="table-light"></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="table-responsive-sm">
                                        <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th class="table-light">Jam Operasional :</th>
                                                        <th class="table-light">Harga Tiket :</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td class="table-light">Pukul 07.00 - 15.00</td>
                                                        <td class="table-light">Tiket masuk Rp. 10.000</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="col-3">
                                    <form>
                                        <div class="form-group ">
                                            <label for="nilai_rating" class="col-form-label">Rating</label> 
                                            <div class="col-12">
                                                <select id="nilai_rating" name="nilai_rating" class="custom-select">
                                                    <option value="1">1. jelek</option>
                                                    <option value="2">2. Kurang Bagus</option>
                                                    <option value="3">3. Biasa Aja</option>
                                                    <option value="4">4. Bagus</option>
                                                    <option value="5">5. Sangat Bagus</option>
                                                </select>
                                            </div>
                                        </div> 
                                        <div class="form-group">
                                            <label for="message-text" class="col-form-label">Message:</label>
                                            <textarea class="form-control" id="message-text"></textarea>
                                        </div>
                                        <div>
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                            <button type="button" class="btn btn-primary">Send</button>
                                        </div> 
                                    </form>
                                    </div>                
                                    <div class="row">
                                    <div class="col-md-12">
                                       <p><b>Obyek wisata Taman Wiladatika dibangun sekitar tahun 1980. Kala itu, peresmiannya dihadiri Bapak Soeharto selaku presiden Indonesia.
                                             Taman ini awalnya dibangun untuk sarana berbagai aktifitas kepramukaan dan penggalangan dana. Wiladatika yang menjadi namanya merupakan singkatan dari Widya Mandala Krida Bakti Pramuka. Seiring berjalannya waktu, Taman Wiladatika pun mulai dikunjungi para wisatawan. Suasananya yang asri dan fasilitasnya yang lengkap menjadi daya tarik tersendiri.
                                             Alhasil, hingga kini Taman Wiladatika Depok ini menjadi salah satu referensi wisata bagi masyarakat Jawa Barat dan sekitarnya.</b></p>
                                    </div>
                                </div>    
                            </div>        
                            </div>
                            </div>
                        </div>
                    </div> 

                    

                </div> <!-- end of col -->
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </div> <!-- end of cards-1 -->
    <!-- end of services -->



    <div id="contact" class="form-2">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2>Contact Information</h2>
                    <ul class="list-unstyled li-space-lg">
                        <li class="address">Jangan ragu untuk menghubungi kami atau mengirimkan pesan formulir kontak</li>
                        <li><i class="fas fa-map-marker-alt"></i>Jl. Bambon Raya No. 7B Rt. 01/01 Beji Timur, Kec. Beji</li>
                        <li><i class="fas fa-phone"></i><a class="turquoise" href="tel:0217757033">0217757033</a></li>
                        <li><i class="fas fa-envelope"></i><a class="turquoise" href="mailto:wisatadepok123@gmail.com">wisatadepok123@gmail.com</a></li>
                    </ul>
                </div> <!-- end of col -->
            </div> <!-- end of row -->
            <div class="row">
                <div class="col-lg-6">
                    <div class="map-responsive">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3965.1383077486985!2d106.81947971427032!3d-6.376140564143356!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69ec03eb2d781f%3A0xcb35cacf2565b957!2sUPTD%20Puskesmas%20Beji!5e0!3m2!1sid!2sid!4v1655969665007!5m2!1sid!2sid" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>                    </div>
                </div> <!-- end of col -->
                <div class="col-lg-6">
                    
                    <!-- Contact Form -->
                   
                       <?php echo form_open("komentar/save") ?>
                        <div class="form-group row">
                            <label for="nama" class="col-4 col-form-label">ID</label> 
                        <div class="col-8">
                        <input id="id" name="id" type="text" class="form-control">
                        </div>
                        </div>
                        <div class="form-group row">
                        <label for="tanggal" class="col-4 col-form-label">Tanggal</label> 
                        <div class="col-8">
                        <div class="input-group">
                            <div class="input-group-prepend">
                            <div class="input-group-text">
                                <i class="fa fa-calendar"></i>
                            </div>
                            </div> 
                            <input id="tanggal" name="tanggal" type="text" class="form-control">
                        </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="isi" class="col-4 col-form-label">Pesan</label> 
                        <div class="col-8">
                        <textarea id="isi" name="isi" cols="40" rows="5" class="form-control"></textarea>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="users_id" class="col-4 col-form-label">Users_id</label> 
                        <div class="col-8">
                        <input id="users_id" name="users_id" type="text" class="form-control">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="faskes_id" class="col-4 col-form-label">Wisata_id</label> 
                        <div class="col-8">
                        <input id="faskes_id" name="faskes_id" type="text" class="form-control">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="rating_id" class="col-4 col-form-label">Rating_id</label> 
                        <div class="col-8">
                        <input id="rating_id" name="rating_id" type="text" class="form-control">
                        </div>
                    </div> 
                    <div class="form-group row">
                        <div class="offset-4 col-8">
                        <button name="submit" type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                <?php echo form_close() ?>
                    <!-- end of contact form -->
                </div> <!-- end of col -->
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </div> <!-- end of form-2 -->
    <!-- end of contact -->


    <!-- Copyright -->
    <div class="copyright">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <p class="p-small">Copyright © 2020 <a href="https://inovatik.com">Inovatik</a> - All rights reserved</p>
                </div> <!-- end of col -->
            </div> <!-- enf of row -->
        </div> <!-- end of container -->
    </div> <!-- end of copyright --> 
    <!-- end of copyright -->
    

    <!-- Scripts -->
    <script src="<?php echo base_url('assets/js/jquery.min.js')?>"></script> <!-- jQuery for Bootstrap's JavaScript plugins -->
    <script src="<?php echo base_url('assets/js/popper.min.js')?>"></script> <!-- Popper tooltip library for Bootstrap -->
    <script src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script> <!-- Bootstrap framework -->
    <script src="<?php echo base_url('assets/js/jquery.easing.min.js')?>"></script> <!-- jQuery Easing for smooth scrolling between anchors -->
    <script src="<?php echo base_url('assets/js/swiper.min.js')?>"></script> <!-- Swiper for image and text sliders -->
    <script src="<?php echo base_url('assets/js/jquery.magnific-popup.js')?>"></script> <!-- Magnific Popup for lightboxes -->
    <script src="<?php echo base_url('assets/js/validator.min.js')?>"></script> <!-- Validator.js - Bootstrap plugin that validates forms -->
    <script src="<?php echo base_url('assets/js/scripts.js')?>"></script> <!-- Custom scripts -->
    <script id="dsq-count-scr" src="" async></script>

</body>
</html>